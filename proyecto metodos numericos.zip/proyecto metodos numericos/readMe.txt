Intrucciones para utilizar el analizador de imagenes:

1. la base de datos debe contener 50 carpetas indexadas como sige: {sub1, sub2,..., sub50}

2. cada carpeta debe contener 5 imagenes indexadas asi "{numeroCarpeta+numeroImagen}" 
    ejemplo:
        para la carpeta de sub9 seria {91.jpg, 92.jpg,..., 95.jpg}

3. en la carpeta inputImage se coloca la imagen que se quiere analizar bajo el nombre de "1.jpg"
